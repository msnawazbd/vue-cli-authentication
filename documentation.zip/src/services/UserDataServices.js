import http from '../http-common'

class UserDataServices {
    create(data){
        return http.post("/register", data)
    }

    login(data){
        return http.post("/login", data)
    }

    user(){
        return http.get("/user")
    }

    categories(){
        return http.get("/categories")
    }
}

export default new UserDataServices()