<template>
  <footer class="bg-dark text-center fixed-bottom">
      <p class="py-3 mb-0 text-light">
        &copy; Copyright 2021. All Right Reserved.
      </p>
    </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
</style>
